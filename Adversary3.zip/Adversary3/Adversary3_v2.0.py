#! /usr/bin/python3
# -*- coding: utf-8 -*-
import sys,cmd,os,atexit,ctypes,re,time,socket,pkg_resources,requests
import platform as p
if "Windows-7" in p.platform():
    print("[!] Non compatible "+p.platform()+" EOL OS detected!")
    print("[!] Adversary3 will NOT output color in console correctly, aborting! :(")
    exit(1)
if not (sys.version_info > (3, 0)):
    print("[!] Adversary3, requires Python 3 :(")
    exit(1)
try:
    from scapy.all import *
except Exception as e:
    print(str(e))
from pathlib import Path
from glob import glob
from io import BytesIO
from zipfile import ZipFile
from pkgutil import iter_modules
from datetime import datetime
###from io import open ##Fix for: encoding is not a valid keyword if run in Python v2.
#+----------------------------------------------------------------------------------+
#Adversary3 - By John Page (aka Malvuln/hyp3rlinx) TM Copyright (c) 2022 MIT License
#Malware vulnerability intel tool for third-party attackers.
#www.malvuln.com
#twitter.com/malvuln
#twitter.com/hyp3rlinx
#malvuln13@gmail.com
#ISR: ApparitionSec
#hyp3rlinx.altervista.org
#VERSION: 2.0 - added new vuln class 'Code Execution'
#=========================================================================================================
#Need a way in but no 0day?, choose the path of least resistance and
#work off the backs of others (virus) flaws.
#Yes, shot in the dark... but vuln backdoors, trojans and virus exist.
#Redteam? look for infected hosts with unsecured backdoors, BoF or RCE.
#On a system with low privs? look for infections with weak permissions
#you get the idea third-party adversary!
#
#NOTE:----------------------------------------
#Tested on Windows 10 Python3 / Kali (Python3)
#Requirements: Windows OS > 7 and Python 3
#Run on Kali: python3 Adversary3.py
#---------------------------------------------
#Commands:
#========
#1)repos: Lists repositories, vulns and amount of each vuln class.
#2)credz: Malware backdoors [PASSWORD] list.
#3)familia: Search number of [VULNS] for all or specific malware [FAMILY].
#4)ports: Lists vuln backdoor malware ports.
#5)md5: Search vulns based on a MD5 malware hash.
#6)mvid: Search vulns based on a MVID malware advisory.
#7)vulns: Browse vuln categories and advisorys, based on the latest downloaded .Zip archive.
#8)md5family: Returns malware [FAMILY][MD5] by family, MD5 or *.
#9)shodan: Crawl the internet for a vuln malware port. Requires a Shodan Enterprise Data license.
#10)scan: Basic port scan for vuln malware ports using half open SYN packet.
# (Note: scan networks or systems for which you have permission to scan)
#11)update: Download and update lastest Adversary3 .Zip from github.com/malvuln.
#12)id: Get MVID, MD5 by MVID, MD5 or wildcard *
#13)cls: Clears the [CONSOLE] window.
#14)about: Explanation of Adversary3.
#=========================================================================================================
#MIT License - Copyright (c) 2022 malvuln
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:

#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.

#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

#Permission is also explicitly given for insertion in vulnerability databases and similar,
#provided that due credit is given to the author John Page (aka malvuln/hyp3rlinx) Copyright (C)(TM) 2022
#========================================================================================================
#DISCLAIMER:
#Author is NOT responsible for any damages whatsoever by using this software,
#by using Adversary3 you assume and accept all risk implied or otherwise.
#=========================================================================================================
URL="https://github.com/malvuln/Adversary3/raw/main/Adversary3.zip"
VIRUS_CREDS_DB="https://raw.githubusercontent.com/malvuln/viruscreds/main/passwords"
SHODAN_URL="https://api.shodan.io/shodan/scan/internet?key="
PAGINATE_AMT=20
OS="win32"
exp_dict = {}
open_ports=[]
familys_hashes = []
fam_hash_set=set()
syn_timeout=5
open_port_dict={"Infected_Host":[], "Port":[]}
virus_port_set=set()
repos_lst=["Authentication Bypass",
          "Buffer Overflow",
          "Code Execution",
          "Command Execution",
          "Credentials",
          "Insecure Crypto",
          "CSRF",
          "Data Modification",
          "Denial of Service",
          "Info Disclosure",
          "Insecure Permissions",
          "MITM",
          "Open Proxy",
          "Path Traversal",
          "Port Bounce Scan",
          "Shell Upload",
          "SQL Injection",
          "Insecure Transit",
          "XSS",
          "XML Injection"]

#Console colors
RED="\033[1;31;40m"
GREY="\033[1;30;40m"
GREEN="\033[1;32;40m"
CYAN="\033[1;36;40m"
YELLOW="\033[1;33;40m"
BOLD = '\033[1m'
ENDC = '\033[m' #Default

BANNER="""
    ___       __                                     _____
   /   | ____/ /   _____  ______________ ________  _|__  /
  / /| |/ __  / | / / _ \/ ___/ ___/ __ `/ ___/ / / //_ < 
 / ___ / /_/ /| |/ /  __/ /  (__  ) /_/ / /  / /_/ /__/ / 
/_/  |_\__,_/ |___/\___/_/  /____/\__,_/_/   \__, /____/  
                                            /____/ v2.0
"""
BANNER2="""
                                     Powered by malware
                                    By malvuln (c) 2022
"""

class Adversary3(cmd.Cmd):
    prompt = RED+"[+] "+GREY+"Cmd: (help/?, <?/topic>)"
    intro = RED+"[+] "+GREY+"Malware vulnz bedazzler"

    def valid_ip(self, addr):
        try:
            socket.inet_aton(addr)
            return True
        except socket.error:
            return False

    def md5_valid(self, md5):
         if len(md5) != 32 or not "".join(re.findall("[a-f0-9]{32}", md5)):
            print(RED+"[!] "+GREY+"Invalid "+RED+"MD5"+GREY)
            return False
         return True

    #Malware ports db
    def do_ports(self, md5):
        """[-] Lookup malware vuln [PORT] by Port, MD5 or or wildcard * \n"""

        virus_port_dict={}
        virus_port=""
        path=""
        all_ports = False
        specific_port=False
        port=False
        paginate=False

        if md5 == "":
            print(RED+"[!] "+GREY+"Not a valid "+RED+"Port, MD5 or * "+GREY)
            return

        if len(md5) <= 5 and md5.isdigit() and md5 != "*":
            if self.valid_port(md5):
                specific_port=md5

        if len(md5) > 32:
            print(RED+"[!] "+GREY+"Port, MD5 or * required")
            return
            
        if not specific_port and md5 != "*" and not "".join(re.findall("[a-f0-9]{32}", md5)):
            print(RED+"[!] "+GREY+"Port, MD5 or * required"+GREY)
            return
            
        if md5=="*":
            all_ports=True
            paginate = input(RED+"[?] "+GREY+"Paginate? "+RED+"Y"+GREY+" or Enter > ").lower()
        
        try:
            path=Path(os.getcwd()+"/exploits/db/PORTS.txt")
            if not os.path.exists(path):
                print(RED+"[!] "+GREY+"No ports avail, run update cmd")
                self.do_help("")
                return
                f = open(path, "w+")
                f.close()
                
            if os.stat(path).st_size == 0:
                print(RED+"[!] "+GREY+"Files empty, no ports avail, run update cmd")
                self.do_help("")
                return
                
            with open(path, "r") as f:
                for m in f:
                    if all_ports:
                        idx = m.find(",")
                        if idx != -1:
                            _hash = m[:idx].replace(","," ")
                            _port = m[idx:].replace(","," ").replace("\n","")
                        if paginate=="y":
                            input(RED+"[-] "+GREY+_hash+RED+_port+GREY)
                        else:
                            print(RED+"[-] "+GREY+_hash+RED+_port+GREY)
                        virus_port_dict[_hash]=_port
                    elif specific_port:
                        idx = m.find(",")
                        _hash = m[:idx].rstrip().lstrip()
                        port = m[idx:].replace(",","").replace("\n","").lstrip()
                        if port==specific_port:
                            virus_port_dict[_hash]=specific_port
                    else: #Port by hash
                        idx = m.find(",")
                        if idx != -1:
                            _hash = m[:idx].lstrip().rstrip()
                            port = m[idx:].replace(",","").replace("\n","")
                            virus_port_dict[_hash]=port
                if specific_port and len(virus_port_dict) != 0:
                    print(RED+"+----------------------------------+")
                    print(RED+"[*] "+GREY+"Malwares using port: "+RED+specific_port+GREY)
                    print(RED+"+----------------------------------+")
                    for p in virus_port_dict:
                        print(RED+"[-] "+GREY+p)
                if md5 in virus_port_dict:
                    virus_port = virus_port_dict[md5]
                    if virus_port:
                        print(RED+"[-] "+GREY+"Vulnerable port: "+RED+virus_port+GREY)
                        print(RED+"+--------------------------------------+"+GREY)
                        self.do_help("")
                        return
                else:
                    if not specific_port and md5 != "*":
                        virus_port_dict={}
            if len(virus_port_dict)==0:
                print(RED+"[!] "+GREY+"Not found")
                return
            if all_ports:
                self.do_help("")
        except Exception as e:
            print(str(e))
            pass
    

    #Grabs malvuln advisory archive from github.com
    def download_and_unzip(self, *args):
        url = args[1]
        hdr = {"User-Agent": "Adversary3 (Malvuln project) 666"}
        archive=""
        try:
            archive = requests.get(url, headers=hdr, stream=True, verify=True)
            if archive.status_code != 200:
                print(RED+"[!] "+GREY+"Problem getting archive try back later :(")
                print(RED+"[!] "+GREY+"HTTP status: "+RED+str(archive.status_code)+GREY)
                self.do_help("")
                return False
            zipfile = ZipFile(BytesIO(archive.content))
            zipfile.extractall(path=".")
            todays_date = datetime.today().strftime('%Y-%m-%d')
            if not os.path.exists("Adversary3_"+str(todays_date)):
                os.rename("Adversary3", "Adversary3_"+str(todays_date))
            else:
                print(RED+"[!] "+GREY+"Adversary3_"+str(todays_date)+" already exists, delete first before updating.")
                return False
        except Exception as e:
            print(str(e))
            pass
            return False
        return True


    #Requires Shodan Enterprise Data license.
    def do_shodan(self, *args):
        """[-] [SHODAN] API to crawl the Internet for specific [VULN PORT]
               Requires Shodan Enterprise Data license\n"""
        global SHODAN_URL
        print(RED+"[*] "+GREY+"Requires a shodan enterprise data lic!")
        port = input("[+] Port to scan or quit >")
        if port=="quit":
            return
        if not self.valid_port(port):
            return
        SHODAN_API_KEY = input("[+] Enter your shodan API key >")
        res=""
        hdr = {"User-Agent": "ADVERSARY3 (Malvuln project) 1.0"}
        params = {'port': port, 'protocol':'http'}
        try:
            res = requests.post(SHODAN_URL + SHODAN_API_KEY, headers=hdr, data=params,  verify=True)
            if res.status_code==200:
                print(RED+"[+] shodan result: "+ GREY + res.content.decode())
                sys.stdout.flush()
            else:
                print(res.content.decode())
                sys.stdout.flush()
        except Exception as e:
            pass


    def do_cmds(self, *args):
        """[!] Display available commands and description \n"""
        print((GREY+"[-] "+RED+"credz: "+GREY+"Malware backdoors [PASSWORD] list\n"+

               GREY+"[-] "+RED+"familia "+GREY+"Search number of [VULNS] for all or specific malware [FAMILY]\n"+

               GREY+"[-] "+RED+"md5family "+GREY+"Returns malware [FAMILY][MD5] by family, MD5 or *\n"+

               GREY+"[-] "+RED+"id "+GREY+"Get [MVID], [MD5] by MD5, MVID or wildcard *\n"+

               GREY+"[-] "+RED+"update "+GREY+"Download and update to the latest [ADVERSARY3] .Zip archive from github\n"+

               GREY+"[-] "+RED+"vulns "+GREY+"Browse malware [ADVISORY] by [EXPLOIT] category\n"+

               GREY+"[-] "+RED+"ports "+GREY+"Lookup malware vuln [PORT] by Port, MD5 or or wildcard *\n"+

               GREY+"[-] "+RED+"mvid "+GREY+"Search malware [VULNS] by [MVID]\n"+

               GREY+"[-] "+RED+"md5 "+GREY+"Search malware [VULNS] by [MD5] may return multiple records\n"+

               GREY+"[-] "+RED+"repos "+GREY+"Lists malware exploit repositories\n"+

               GREY+"[-] "+RED+"shodan "+GREY+"[SHODAN] API to crawl the Internet for specific [VULN PORT]\n"+
                  "\tRequires Shodan Enterprise Data license\n"+

               GREY+"[-] "+RED+"scan "+GREY+"Scan IP or network range for known Malware [PORT] using SYN packet\n"+
                    "\tE.g. scan x.x.x.x 9000, scan x.x.x.x 49931 /24, scan x.x.x.x 3333 - 5000\n"+
               
               GREY+"[-] "+RED+"about "+GREY+"What is Adversary3\n"+

               GREY+"[-] "+RED+"cls "+GREY+"Clears console window"))

        

    #Updates the local Adversary3 database framework
    def do_update(self, *args):
        """[-] Download and update to the latest [ADVERSARY3] .Zip archive from github\n"""
        global URL

        print(RED+"[+] "+GREY+"Downloading latest Adversary3.zip ...")
        if self.download_and_unzip(self, URL):
            time.sleep(1)
            print(RED+"[-] "+GREY+"Downloaded successfully to: "+str(Path(os.getcwd())))
            sys.stdout.flush()


    def do_mvid(self, *args):
        """[!] Search malware [VULNS] by [MVID] \n"""
        global repos_lst
        _id = args[0]
        vuln=""
        file_path=""
        if not re.findall("MVID-+\d{4}-\d{4}", _id):
            print(RED+"[!] "+GREY+"Invalid "+RED+"MVID")
            print(RED+"[!] "+GREY+"Need an MVID? "+RED+"run"+GREY+" id *")
            return
        path = Path(os.getcwd()+"/exploits/db/MVID_DB.txt")
        if not os.path.exists(path):
            print(RED+"[!] "+GREY+"No data try running update cmd")
            return
        try:
            f = open(path, "r")
            for mvid in f:
                idx = mvid.find(":")
                if idx != -1:
                    if _id == mvid[:idx]:
                        vuln = mvid[idx + 1:].rstrip()
            f.close()
            if not vuln:
                print(RED+"[!] "+GREY+"MVID "+RED+"not"+GREY+" found")
                return
            for r in repos_lst:
                data_folder = Path(os.getcwd()+"/exploits/"+r+"/"+vuln)
                if os.path.exists(data_folder):
                    f2 = open(data_folder, "r")
                    paginate = input(RED+"[?] "+GREY+"Paginate? "+RED+"Y"+GREY+" or Enter > ").lower()
                    for x in f2:
                        if paginate=="y":
                            input(x.replace("\n", ""))
                        else:
                            print(x.replace("\n", ""))
                    break
                    f2.close()
        except Exception as e:
            print(str(e))
            pass


    def do_id(self, *args):
        """[!] Get [MVID], [MD5] by MD5, MVID or wildcard * \n"""
        param = args[0].lstrip().rstrip()
        paginate=False
        
        if len(param)==32:
            if not self.md5_valid(param):
                return
        elif param != "*":
            if not re.findall("MVID-+\d{4}-\d{4}", param):
                print(RED+"[!] "+GREY+"Not a valid "+RED+"MVID, MD5 or *"+GREY)
                return
                
        path =  Path(os.getcwd()+"/exploits/db/MVID_DB.txt")
        if not os.path.exists(path):
            print(RED+"[!] "+GREY+"No data try running update cmd")
            return
        try:
            multi_records=[]
            f = open(path, "r")
            if param == "*":
                paginate = input(RED+"[?] "+GREY+"Paginate? "+RED+"Y"+GREY+" or Enter > ").lower()
            for mvid in f:
                #remove .txt
                idx = mvid.find(".")
                if idx != -1:
                    mvid = mvid[:idx]
                #remove _+[A-D]
                idx = mvid.find("_")
                if idx != -1:
                    mvid = mvid[:idx]
                idx = mvid.find(":")
                if idx != -1:
                    if param==mvid[idx + 1:]:
                        multi_records.append(param)
                    #get MD5 from MVID
                    if param == mvid[:idx]:
                        print(RED+"[*] MD5 "+GREY +mvid[idx + 1:])
                        return
                    #get MVID from MD5
                    if param == mvid[idx + 1:]:
                        print(RED+"[*] MVID: "+GREY+mvid[:idx])
                #get all
                if param == "*":
                    if paginate=="y":
                        input(RED+"[-] "+GREY+mvid.replace("\n", ""))
                    else:
                        print(RED+"[-] "+GREY+mvid.replace("\n", ""))
            f.close()
            if len(multi_records) > 1:
                print(RED+"[*] "+GREY+"Multiple records for this hash")
            if param != mvid[:idx] and param != mvid[idx + 1:] and param !="*" and len(multi_records)==0:
                print(RED+"[!] "+GREY+"Not found")
                return
        except Exception as e:
            print(str(e))
            pass


    #Search for the do_family func
    def search_family(self, fam):
        """[-] Search total number of [VULNS] for all or specific malware [FAMILY]\n"""
        family_dict={}
        fam = fam.lower()
        num=""
        with open(Path(os.getcwd()+"/exploits/db/FAMILYS.txt"), "r+") as f:
            for families in f:
                families = families.replace("\n","").lower()
                idx = families.rfind(" ")
                if idx != -1:
                    fams=families[:idx]
                    num_vulns=families[idx:]
                    family_dict[fams]=num_vulns
            try:
                num = family_dict[fam]
                if fam=="agent":
                    fam = fam + " (generic)"
                fam = "".join(fam[0].upper() + fam[1:].lower())
                print(RED+"[-] "+GREY+fam+ " has"+RED+num+GREY+" vulnz")
            except KeyError as e:
                print(RED+"[!] "+GREY+"No vulns found for "+RED+fam+GREY+" check back later.")
                self.do_help("")
                pass


    #TODO: most vuln family award Lol
    def do_familia(self, *args):
        """[-] Search total number of [VULNS] for all or specific [MALWARE] familys \n"""
        
        global PAGINATE_AMT
        malware_fam_lst=[]
        amt=0
        path=""

        path = Path(os.getcwd()+"/exploits/db/FAMILYS.txt")
        if not os.path.exists(path):
            f = open(path, "w+")
            f.close()
        with open(path, "r") as f:
            for m in f:
                if m != "" and m.strip():
                    malware_fam_lst.append(m)
            lst = sorted(malware_fam_lst)
        if not malware_fam_lst:
            print(RED+"[!] "+GREY+"No families, try update to latest archive!")
            return

        #Single family search
        if args[0]:
            if re.findall(r"^[a-z]+[a-z0-9]", args[0], re.IGNORECASE):
                self.search_family(args[0])
            else:
                print(RED+"[!] "+GREY+"Unknown malware family")
            return
        
        lst = sorted(malware_fam_lst)
        specimen_lst=[]
        tmp=""
        idx=-1
        paginate=0

        for j in lst:
            idx = j.rfind(" ")
            if idx != -1:
                specimen_lst.append(j.rstrip())  
        if len(specimen_lst) > PAGINATE_AMT:
            paginate = input(RED+"[?] "+GREY+"Paginate? "+RED+"Y"+GREY+" or Enter > ").lower()
        if paginate=="y":
            print("+-------------------------------+")
            print(RED+"[!] "+GREY+"Enter to Page Down.")
            print("+-------------------------------+")
        for x in specimen_lst:
            if paginate=="y":
                input(RED+"[-] "+GREY+x)
            else:
                print(RED+"[-] "+GREY+x)
            amt += 1
        print(RED+"[*] "+GREY+"Number of families: "+RED+str(amt)+GREY)
        if len(specimen_lst) < PAGINATE_AMT:
            print(RED+"[!] "+GREY+"Run update to get lastest vulnz")
        malware_fam_lst = False
        specimen_lst = False
        

    def do_md5(self, *args):
        """[!] Searches malware [VULNS] by [MD5] may return multiple records \n """
        md5=args[0]
        if not self.md5_valid(md5):
            print(RED+"[!] "+GREY+"Need an MD5? "+RED+"run"+GREY+" id *")
            return
            
        dir_lst = glob("exploits/*")
        track=0
        multi_record_set = set()
        for d in dir_lst:

            #Catalog up to four vulns for a single malware
            if os.path.exists(Path(d+"/"+md5+".txt")):
                multi_record_set.add(Path(d+"/"+md5+".txt"))
                
            if os.path.exists(Path(d+"/"+md5+"_B.txt")):
                multi_record_set.add(Path(d+"/"+md5+"_B.txt"))
                
            if os.path.exists(Path(d+"/"+md5+"_C.txt")):
                multi_record_set.add(Path(d+"/"+md5+"_C.txt"))
                
            if os.path.exists(Path(d+"/"+md5+"_D.txt")):
                multi_record_set.add(Path(d+"/"+md5+"_D.txt"))
        
        if len(multi_record_set) > 1:
            print(RED+"+------------------------------------------------+")
            print(RED+"[!] "+GREY+"Found multiple records for this malware hash!")
            print(RED+"+------------------------------------------------+"+GREY)
        for record in multi_record_set:
            track += 1
            with open(record, "r", encoding="utf8") as f:
                print("\n"+RED+"[!] Enter to Page Down."+GREY)
                print(RED+"[-] "+GREY+"+-----------------+")
                for e in f:
                    input(e.replace("\n", ""))
                    #may change this later.
                    if e.find("Disclaimer:") != -1 and track == len(multi_record_set): 
                        print("\n")
                        return
        if track == 0:
            print(RED+"[!] "+GREY+"Vuln "+RED+"not"+GREY+" found for: "+RED+md5+GREY)


    def do_md5family(self, *args):
        """[!] Returns malware [FAMILY][MD5] by family, MD5 or *\n"""
        global fam_hash_set
        lst = []
        fam_hash_set=set()
        family=""
        paginate=False
        f=None

        if len(args[0])==32:
            if not self.md5_valid(args[0]):
                return
        
        if args[0] == "" and args[0] != "*":
            print(RED+"[!] "+GREY+"Invalid"+RED+" MD5, family or *"+GREY)
            return
            
        if args[0] == "*":
            family = ""
            paginate = input(RED+"[?] "+GREY+"Paginate? "+RED+"Y"+GREY+" or Enter > ").lower()
        else:
            family = args[0]

        path = Path(os.getcwd()+"/exploits/db/FAMILIA_HASH.txt")
        if os.path.exists(path):  
            f = open(path, "r")
        else:
            print(RED+"[!] "+GREY+"Hashes not found, try the run update command.")
            return
            
        for tmp in f:
            lst.append(tmp)
        f.close()

        sorted_lst = sorted(lst)
        indices = [i for i, x in enumerate(sorted_lst) if family in x]
        for i in indices:
            sorted_lst[i] = sorted_lst[i].replace(",", ":")
            fam_hash_set.add(sorted_lst[i])

        if len(fam_hash_set)==0:
            print(RED+"[!] "+GREY+"Malware family not found")
            
        if len(fam_hash_set) != 0:
            print(RED+"+-----------------------------------------------------+")
            print(RED+"[*] "+GREY+"Results for "+RED+args[0])
            for gg in fam_hash_set:
                if paginate=="y":
                    input(RED+"[-] "+GREY+gg.replace("\n",""))
                else:
                    print(RED+"[-] "+GREY +gg.replace("\n",""))
            print(RED+"+-----------------------------------------------------+"+GREY)


    def do_vulns(self, *args):
        """[!] Browse malware [ADVISORY] by [EXPLOIT] category \n"""

        global exp_dict
        
        self.selection=args[0]
        
        if args[0]=="":
            self.selection=None

        #User called vulns from already inside a selected category.
        if args[0]==666:
            self.selection=None

        if self.selection:
            os.chdir("../")

        try:
            if len(exp_dict) != 0:
                exp_dict.clear()
            c=0
            os.chdir("exploits")
            dirs = sorted(glob("*"))
            dlen = len(dirs)
        
            #Give option to select a category (dir) list vulns.
            print(RED+"\n*** Malware Exploit Categories ***\n"+GREY)
                
            for d in dirs:
                #User hit B (back) so suppress show cats again.
                path = Path(os.getcwd()+"/"+d)
                if os.path.isdir(path):
                    if d != "db": #flat file database
                        c+=1
                        print(RED+"["+str(c)+"] "+GREY+d)
                        exp_dict[c]=d

            if self.selection is not None:
                if unicode(self.selection).isnumeric() and int(self.selection) <= len(exp_dict):
                    self.get_advisory(exp_dict[int(self.selection)], self.selection)
                    return
            while True:
                self.selection = input("\n"+RED+"[+] "+GREY+"Select number, Enter or "+RED+"(b)"+GREY+" to go back"+GREY+" > ").lower()
                if self.selection=="b" or self.selection=="back":
                    self.do_help("")
                    os.chdir("../")
                    break
                    
                if self.selection=="quit":
                    self.do_quit()
                    
                if unicode(self.selection).isnumeric() and int(self.selection) <= len(exp_dict):
                    self.get_advisory(exp_dict[int(self.selection)], self.selection)
                    break
                else:
                    print(RED+"[!] "+GREY+"Invalid selection")
                    continue
        except Exception as e:
            print(str(e))
            pass
        

    def get_advisory(self, *args):
        if len(args)==2:
            self.category=args[0]
            self.selection=args[1]
            
        global cnt, j, tmp, PAGINATE_AMT
        lst=[]
        cnt=-1
        print_once=False
        md5_dict={}
        tmp=""
        #All advisories live under exploits dir.
        try:
            f=open(self.category+"/"+self.category+".txt", "r")
            for vuln in f:
                if vuln != "" and vuln != None:
                    idx = vuln.rfind("/")
                    if idx != -1:
                        cnt += 1
                        tmp = vuln[idx + 1:].lstrip().replace("\n","")
                        md5_dict[str(cnt)] = tmp
                        lst.append("[+] "+str(cnt)+" "+vuln.replace("\n",""))
            f.close()
            if len(lst)==0:
                print(RED+"[!] "+GREY+"No exploits avail for this category, try back later")
                os.chdir("../")
                return

            print("+-------------------------------------------------------------------------------------------+")
            print(RED+"[*] "+GREY+"Avail "+RED+self.category+GREY+" exploits:")
            print("+-------------------------------------------------------------------------------------------+")

            paginate = False
            if len(lst) > PAGINATE_AMT:
                paginate = input(RED+"[?] "+GREY+"Paginate? "+RED+"Y"+GREY+" or Enter > ").lower()
                if paginate=="quit":
                    self.do_quit()
            for x in lst:
                if paginate=="y":
                    if not print_once:
                        print(RED+"[*] Enter to page down."+GREY)
                        print_once=True
                    input(x)
                else:
                    print(x)

            amt_of_exploits = len(lst)
            idx=-1
            page_down=False
            print_once=False
            while True:
                exp_sel = input("\n[+] "+RED+"B (back) or (vulns)"+GREY+", (read option: "+RED+"<Num> OR <Num>|more)"+GREY+" > ").lower()
                idx = exp_sel.replace(" ","").find("|more") 
                if idx != -1:
                    page_down=True
                    exp_sel = exp_sel[:idx]
                if unicode(exp_sel).isnumeric() and int(exp_sel) <= amt_of_exploits:
                    try:
                        f=open(self.category+"/"+md5_dict[exp_sel], "r", encoding="utf8")
                        for e in f:
                            if not page_down:
                                print(e.replace("\n", ""))
                                sys.stdout.flush()
                            #Acts like | more
                            else:
                                if not print_once:
                                    print(RED+"[*] Enter to page down."+GREY)
                                    print_once=True
                                input(e.replace("\n", ""))
                        f.close()
                        page_down=False
                    except Exception as e:
                        pass
                else:
                    if exp_sel != "quit" and exp_sel != "b" and exp_sel != "back" and exp_sel != "vulns":
                        print(RED+"[!] "+GREY+"Invalid option")
                #User wants go Back
                if exp_sel=="back" or exp_sel=="b":
                    self.do_help("")
                    os.chdir("../")
                    break
                
                #call vulns
                if exp_sel=="vulns":
                    self.do_vulns(self, 666)
                    break
                    
                #User wants exit out
                if exp_sel=="quit":
                    self.do_quit()
                continue
        except Exception as e:
            print(str(e))
            pass


    #Syn + ACK + RST port is open
    #Syn + RST port is closed
    def syn(self, *args):
        global syn_timeout, open_port_dict, open_ports

        if len(args) == 3:
            dst_ip = args[0]
            src_port = args[1]
            dst_port = args[2]
        try:
            res = sr1(IP(dst=dst_ip)/TCP(sport=src_port,dport=dst_port,flags="S"),verbose=False,timeout=syn_timeout)
            if res==None or str(type(res[TCP].flags))=="<type 'NoneType'>":
                print(RED+"[!] "+YELLOW+"Closed or host not up "+GREY+dst_ip)
                sys.stdout.flush()
                return
            if res is not None:
                if TCP in res:
                    if(res[TCP].flags == 0x12):
                        open_ports.append(RED+"[*] "+GREEN+"Port "+str(dst_port)+ " Open "+GREY+dst_ip)
                        time.sleep(2)
                        sys.stdout.flush()
                        #RST
                        send(IP(dst=dst_ip)/TCP(sport=src_port,dport=dst_port,flags="R",timeout=syn_timeout),verbose=False)
                        return
                    if(res[TCP].flags == 0x14):
                        print(RED+"[!] "+YELLOW+"Port "+GREY+str(dst_port) +" Closed "+dst_ip)
                        sys.stdout.flush()
                        return
                if ICMP in res:
                    if(int(res[ICMP].type)==3 and int(res[ICMP].code) in [1,2,3,9,10,13]):
                        print(RED+"[!] "+YELLOW+"Port "+GREY+str(dst_port) + " Filtered "+dst_ip)
                        sys.stdout.flush()
                        return
        except Exception as e:
            print("Error: "+str(e))
            pass


    #Enforce admin when required.
    def isAdmin(self, *args):
        try:
            is_admin = (os.getuid() == 0)
        except AttributeError:
            is_admin = ctypes.windll.shell32.IsUserAnAdmin() != 0
        if not is_admin:
            print(RED+"[!] "+CYAN+"Port scans require an elevated command line.")
            return False
        return True


    def do_about(self, *args):
        """[!] What is Adversary3 ?\n"""
        print(RED+"[-] "+GREY+"Malware vulnerability intel tool for third-party attackers\n"+RED+
        "[-] "+GREY+"Need a way in but no 0day?, choose the path of least resistance\n"+RED+
        "[-] "+GREY+"Profit off the backs and work of others (virus) flaws.\n"+RED+
        "[-] "+GREY+"yes, shot in the dark... but vuln backdoors, trojans and virus exist.\n"+RED+
        "[-] "+GREY+"Redteam? look for infected hosts with unsecured backdoors, BoF or RCE.\n"+RED+
        "[-] "+GREY+"On a system and no privs? look for infections with weak permissions\n"+RED+
        "[-] "+GREY+"you get the idea 3rd party adversary!")


    #Handle single IP with single port or port range.
    def do_scan(self, params):
        """[-] Scan IP or network range for known Malware [PORT] using SYN packet
              E.g. scan x.x.x.x 9000, scan x.x.x.x 49931 /24, scan x.x.x.x 3333 - 5000\n"""

        global open_ports

        if params == "":
            print("[!] Scan IP or network range for known Malware [PORT] using scapy.\n"+
                  "E.g. scan x.x.x.x 9000, scan x.x.x.x 49931 /24, scan x.x.x.x 3333 - 5000")
            return

        #Rights check
        if not self.isAdmin():
            return

        print(RED+"[!] "+CYAN+"only scan authorized networks"+GREY)
        
        q = input("[+] Y to continue or quit > ")
        if q=="quit":
            return

        _args = params.split(" ")
        ip_range=""

        if len(_args) < 2:
            print("[!] Usage: scan x.x.x.x 22, scan x.x.x.x 22 /24")
            return
        
        self.ip = _args[0].rstrip()
        self.port = _args[1].rstrip()
        
        if not self.valid_ip(self.ip):
            print(RED+"[!] "+GREY+"Invalid IP address")
            return
        
        self.netid = None
   
        if len(_args) == 3:
            self.netid = _args[2]
            
        start = 0
        end = 0

        try:
            if self.netid != None:
                ip_range = IP(dst=self.ip+self.netid)
            else:
                ip_range = IP(dst=self.ip)
        except Exception as e:
            print(str(e) + " is scapy installed?")
            return

        #Chk if port range e.g. 21-1024.
        if self.port.find("-") != -1:
            ports = str(self.port).split("-")
            if not self.valid_port(unicode(ports[0])):
                return
            else:
                start = int(ports[0])
            if not self.valid_port(unicode(ports[1])):
                return
            else:
                end = int(ports[1]) + 1
        else:
            if not self.valid_port(self.port):
                return
        
        if self.netid:

            for _ip in ip_range:

                ##print("[-]" + _ip.summary())
                if start:
                    for p in range(int(start), int(end)):
                        rport=RandNum(1024,65535)
                        s = Thread(target=self.syn, args=(_ip.dst, rport, int(p)))
                        s.start()
                
                else:
                    #Scan CIDR and single port
                    rport=RandNum(1024,65535)
                    #self.syn(_ip.dst, int(rport), int(self.port))
                    t = Thread(target=self.syn, args=(_ip.dst, int(rport), int(self.port)))
                    t.daemon = True
                    t.start()

        else:

            print("[-]" + ip_range.summary())
            
            if start:
                for p in range(start, end):
                    rport=RandNum(1024,65535)
                    self.syn(ip_range.dst, rport, int(p))
                    t = Thread(target=self.syn, args=(ip_range.dst, rport, int(p)))
                    t.daemon = True
                    t.start()
                    
            #Scan single port
            else:
                rport=RandNum(1024,65535)
                self.syn(ip_range.dst, rport, int(self.port))
                
        #Display port result
        for tested in open_ports:
            print(tested)
            open_ports.remove(tested)
                

    def do_repos(self, *args):
        """[-] Lists malware exploit repositories\n"""
        global repos_lst
        print("+--------------------------------------+")
        print(RED+"[+] Vuln repositories"+GREY)
        print("+--------------------------------------+")
        total=-1
        for c in repos_lst:
            lst = os.listdir("exploits/"+c)
            print(RED+"[-] "+GREY+c + ": "+RED+str(len(lst) -1) + GREY+" avail exploits")
            total += len(lst) -1
        print("+--------------------------------------+")
        print(RED+"[*] "+GREY+"Total Malware Vulnz: "+RED+str(total)+GREY)
        print("+--------------------------------------+")

        

    def do_credz(self, *args):
        """[-] Malware backdoors [PASSWORD] list \n"""
        paginate=False
        try:
            path = Path(os.getcwd()+"/exploits/db/CREDS.txt")
            if not os.path.exists(path):
                f = open(path, "w+")
                f.close()
                print(RED+"[!] "+GREY+"No virus credz avail, run update cmd")
                return
            with open("exploits/db/CREDS.txt", "r") as f:
                lst = f.readlines()
                if len(lst)==0:
                    print(RED+"[!] "+GREY+"No virus credz avail, run update cmd")
                    return
                if len(lst) > PAGINATE_AMT:
                    paginate = input(RED+"[?] "+GREY+"Paginate? "+RED+"Y"+GREY+" or Enter > ").lower()
                for pwd in lst:
                    if pwd != "" and pwd != "\n":
                        if paginate=="y":
                            input(RED+"[+] "+GREY+pwd.rstrip())
                        else:
                            print(RED+"[+] "+GREY+pwd.rstrip())
        except Exception as e:
            print(str(e))

    def valid_port(self, port):
        try:
            if not port.isdigit():
                print(RED+"[!] "+YELLOW+"Invalid port"+GREY)
                return False
        except Exception as e:
            pass
        if int(port) <= 65535:
            return True
        return False

                
    def emptyline(self):
        pass

    #Clears console
    def do_cls(self, *args):
        """[-] Clears the [CONSOLE] window """
        global OS
        if OS=="Linux":
            os.system("clear")
        else:
            os.system("cls")
        banner()
        self.do_help("")


    def do_quit(self, *args):
        """[!] Exit the adversary3 framework \n"""
        print(RED+"[*] "+GREY+"Long live 3rd party attackers!, "+RED+"MALVULN "+GREY+"for3ver!")
        #Return console to default color
        print(ENDC)
        exit()
        return True

def banner():
    global OS
    if OS != "Linux":
        os.system("color")
    print(RED + BANNER + GREY)
    print(BANNER2)

#Try ensure required modules exist
def haslib(lib):
    if not lib in (name for loader, name, ispkg in iter_modules()):
        print("[!] "+lib+ " does not exist, pip install "+lib)
        exit()
    return True

def package_chk():
    for package in ['scapy', 'requests']:
        try:
            dist = pkg_resources.get_distribution(package)
            pass
            #print('{} ({}) is installed'.format(dist.key, dist.version))
        except pkg_resources.DistributionNotFound:
            print('{} is NOT installed'.format(package))
            return False
    return True

#Try handle known bugs in scapy versions
def scapy_ver():
    ver = pkg_resources.get_distribution("scapy").version
    if ver=="2.4.1" or ver=="2.4.2":
        print(RED+"[!] WARN "+GREY+"Known bugs in scapy versions 2.4.1 and 2.4.2")
        print(RED+"[!] "+GREY+"Scapy version detected is " +RED+ver+GREY+" update to 2.4.3 or latest.")
        return False
    return True


#Change console back to default if script exited unclean
def exit_handler():
    print(ENDC)

def lib_chk():
    try:
        if haslib("scapy"):
            scapy_ver()
    except Exception as e:
        if str(e) == "cannot import name NPCAP_PATH": 
            scapy_ver()
            return False
    try:
        if haslib("requests"):
            import requests
    except Exception as e:
        return False
    return True
                
if __name__ == '__main__':
    #In case the script is moved and cant see exploits dir.
    if not os.path.exists(Path(os.getcwd()+"/exploits")):
        print("[!] Can't locate the exploits directory. Adversary3.py and exploits must exist side by side.")
        print("[-] Download a new build by running the update cmd, then cd into.")

    if sys.version_info[0] >= 3:
        unicode = str

    if not package_chk():
        print("[!] Install required Python modules")
        exit(1)
                
    if lib_chk():
        try:
            _os = sys.platform
            if _os!="win32":
                OS="Linux"
            banner()
            atexit.register(exit_handler)
            Adversary3().cmdloop()
        except Exception as e:
            print(str(e))
            exit(1)
    
    
